import { useState } from "react";
import "./App.css";

export default function App() {
    // Estados para armazenar o que o usuário digita
    const [peso, setPeso] = useState("");
    const [altura, setAltura] = useState("");
    const [resultado, setResultado] = useState(null);

    // Função para calcular
    function calcularIMC() {
        // Validamos se os campos não estão vazios
        if (peso === "" || altura === "") {
            alert("Por favor, preencha todos os campos!");
            return;
        }

        // Convertemos o texto para número (importante para o cálculo)
        const valorPeso = parseFloat(peso);
        const valorAltura = parseFloat(altura);

        if (valorPeso > 0 && valorAltura > 0) {
            const imc = valorPeso / (valorAltura * valorAltura);
            setResultado(imc.toFixed(2)); // Guarda o resultado com 2 casas decimais
        } else {
            alert("Valores inválidos!");
        }
    }

    // Função para limpar os campos
    function limpar() {
        setPeso("");
        setAltura("");
        setResultado(null);
    }

    return (
        <div className="container">
            <h1>Calculadora IMC</h1>

            <div className="input-group">
                <p>Seu Peso (kg)</p>
                <input
                    type="number"
                    placeholder="Ex: 70.5"
                    value={peso}
                    onChange={(e) => setPeso(e.target.value)}
                />
            </div>

            <div className="input-group">
                <p>Sua Altura (m)</p>
                <input
                    type="number"
                    placeholder="Ex: 1.75"
                    value={altura}
                    onChange={(e) => setAltura(e.target.value)}
                />
            </div>

            <div className="button-group">
                <button className="btn-calc" onClick={calcularIMC}>Calcular</button>
                <button className="btn-limpar" onClick={limpar}>Limpar</button>
            </div>

            {/* Só mostra essa div se o resultado existir */}
            {resultado && (
                <div className="resultado-area">
                    <h3>Seu IMC é:</h3>
                    <span className="valor-resultado">{resultado}</span>
                </div>
            )}
        </div>
    );
}